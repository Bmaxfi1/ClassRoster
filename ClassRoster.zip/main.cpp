#include <iostream>
#include <string>

#include "roster.h"

using namespace std;

int main()
{	
	cout << "<<<<  Welcome to ClassRoster!  >>>>" << endl;
	cout << "-----------------------------------" << endl;
	cout << "Scripting & Programming Applications" << endl;
	cout << "Written in C++" << endl;
	cout << "WGU Student Id: 001426587" << endl;
	cout << "Created by: Brandon Maxfield" << endl;

	Roster classRoster;
	classRoster.parseTableForStudentData();
	///////////////////////////////////////////////////////////////////////////////////////////////////////////
	//PSUEDOCODE START
	//
	classRoster.PrintAll();

	classRoster.PrintInvalidEmails();

	//loop through classRosterArray and for each element:
	for (int i = 0; i < classRoster.numStudents; i++)
	{
	classRoster.PrintAvgDaysInCourse(classRoster.classRosterArray[i].getStudentId());
	}

	classRoster.PrintByDegreeProgram(SOFTWARE);

	classRoster.Remove("A3");

	classRoster.PrintAll();

	classRoster.Remove("A3");
	//expected: the above line should print a message saying such a student with this ID was not found.

	//
	//PSUEDOCODE END
	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	while (bool remain = true)
	{
		cout << "-----------------------------------" << endl;
		string chosenCommand = "";
		string studId = "";
		string pickedDegreeString = "";
		DegreeProgram pickedDegree;

		cout << "Please enter a command." << endl;
		cout << "(valid commands are: ADD, REMOVE, PRINTALL, AVGCOURSELENGTH, INVALIDEMAILS, LISTBYDEGREE and EXIT)" << endl;
		cin >> chosenCommand;

		if (chosenCommand == "ADD")
		{
			classRoster.Add();
			continue;
		}
		if (chosenCommand == "REMOVE")
		{
			cout << "Enter student Id." << endl;
			cin >> studId;
			classRoster.Remove(studId);
			continue;
		}
		if (chosenCommand == "PRINTALL")
		{
			classRoster.PrintAll();
			continue;
		}
		if (chosenCommand == "AVGCOURSELENGTH")
		{
			cout << "Enter student Id." << endl;
			cin >> studId;
			classRoster.PrintAvgDaysInCourse(studId);
			continue;
		}
		if (chosenCommand == "INVALIDEMAILS")
		{
			classRoster.PrintInvalidEmails();
			continue;
		}
		if (chosenCommand == "LISTBYDEGREE")
		{	
			pickedDegreeString = "";
			cout << "Enter degree type:" << endl;
			cout << "(SECURITY, NETWORK, or SOFTWARE)" << endl;
			cin >> pickedDegreeString;

			if (pickedDegreeString == "SECURITY") {
				pickedDegree = SECURITY;
			}
			else if (pickedDegreeString == "NETWORK") {
				pickedDegree = NETWORK;
			}
			else if (pickedDegreeString == "SOFTWARE") {
				pickedDegree = SOFTWARE;
			}
			else {
				cout << "Degree unidentified.  Showing 'SOFTWARE'." << endl;
				pickedDegree = SOFTWARE;
			};

			classRoster.PrintByDegreeProgram(pickedDegree);
			continue;
		}
		if (chosenCommand == "EXIT")
		{
			remain = false;
			break;
		}
		else
		{
			cout << "Invalid command.  Please try again." << endl << endl;
		};
	};

	delete[] classRoster.classRosterArray;  //destructor
	return 0;
}
